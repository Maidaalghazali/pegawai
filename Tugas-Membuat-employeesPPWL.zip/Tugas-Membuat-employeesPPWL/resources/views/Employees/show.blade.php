<!-- resources/views/employees/show.blade.php -->
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Detail Pegawai</h5>
                </div>

                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Nama</div>
                        <div class="col-md-8">{{ $employee->name }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Jabatan</div>
                        <div class="col-md-8">{{ $employee->position }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Departemen</div>
                        <div class="col-md-8">{{ $employee->department ?: '-' }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Gaji</div>
                        <div class="col-md-8">Rp {{ number_format($employee->salary, 0, ',', '.') }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Email</div>
                        <div class="col-md-8">{{ $employee->email ?: '-' }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Nomor Telepon</div>
                        <div class="col-md-8">{{ $employee->phone ?: '-' }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Tanggal Bergabung</div>
                        <div class="col-md-8">{{ $employee->hire_date ? date('d F Y', strtotime($employee->hire_date)) : '-' }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Tanggal Dibuat</div>
                        <div class="col-md-8">{{ date('d F Y H:i', strtotime($employee->created_at)) }}</div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Terakhir Diperbarui</div>
                        <div class="col-md-8">{{ date('d F Y H:i', strtotime($employee->updated_at)) }}</div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="{{ route('employees.index') }}" class="btn btn-secondary">Kembali</a>
                        <div>
                            <a href="{{ route('employees.edit', $employee->id) }}" class="btn btn-warning me-2">Edit</a>
                            <form action="{{ route('employees.destroy', $employee->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Apakah anda yakin ingin menghapus data ini?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Hapus</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection